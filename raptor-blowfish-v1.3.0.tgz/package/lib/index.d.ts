import { Cipher } from './cipher';
import { Decipher } from './decipher';
export declare class Fish {
    static createCipher(key: string): Cipher;
    static createDecipher(key: string): Decipher;
}
