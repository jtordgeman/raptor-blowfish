import { Decipher } from './decipher';
export declare class BlowfishDecipherCBC implements Decipher {
    private key;
    constructor(key: string);
    decrypt(input: string): string;
}
