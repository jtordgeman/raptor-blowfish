import { Cipher } from './cipher';
export declare class BlowfishCipherECB implements Cipher {
    private key;
    constructor(key: string);
    encrypt(input: string): string;
}
