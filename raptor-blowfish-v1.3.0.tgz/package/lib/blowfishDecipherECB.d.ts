import { Decipher } from './decipher';
export declare class BlowfishDecipherECB implements Decipher {
    private key;
    constructor(key: string);
    decrypt(input: string): string;
}
