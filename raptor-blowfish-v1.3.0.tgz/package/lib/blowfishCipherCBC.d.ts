import { Cipher } from './cipher';
export declare class BlowfishCipherCBC implements Cipher {
    private key;
    constructor(key: string);
    encrypt(input: string): string;
}
