/// <reference types="node" />
export declare const toBlowfishBase64: (buf: Buffer) => string;
export declare const pad: (input: string, len: number) => string;
export declare const padBuffer: (input: Buffer, len: number) => Buffer;
export declare const fromBlowfishBase64: (input: string) => Buffer;
